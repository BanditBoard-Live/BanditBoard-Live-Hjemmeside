//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CfAGR-_C.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/konto",
			"/login",
			"/opret",
			"/api/auth/$",
			"/api/board/session",
			"/api/board/state"
		],
		preloads: [
			"/assets/index-2tL61nCB.js",
			"/assets/react-DB-4Zxce.js",
			"/assets/preload-helper-b6AV88ay.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-2tL61nCB.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Cx1m1Bpr.js",
			"/assets/site-shell-VHKzayv1.js",
			"/assets/users-DyZNzQos.js"
		]
	},
	"/admin": {
		filePath: "/workspace/src/routes/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-D5AuigbI.js",
			"/assets/site-shell-VHKzayv1.js",
			"/assets/auth-card-85ccPt56.js",
			"/assets/gates-Bd78WShY.js"
		]
	},
	"/konto": {
		filePath: "/workspace/src/routes/konto.tsx",
		children: void 0,
		preloads: [
			"/assets/konto-BlYUGVGO.js",
			"/assets/site-shell-VHKzayv1.js",
			"/assets/users-DyZNzQos.js",
			"/assets/auth-card-85ccPt56.js",
			"/assets/gates-Bd78WShY.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-CYMxE1om.js",
			"/assets/site-shell-VHKzayv1.js",
			"/assets/client-bLCk0icn.js",
			"/assets/auth-card-85ccPt56.js",
			"/assets/remember-session-Db6chzQY.js"
		]
	},
	"/opret": {
		filePath: "/workspace/src/routes/opret.tsx",
		children: void 0,
		preloads: [
			"/assets/opret-CAppAOMV.js",
			"/assets/site-shell-VHKzayv1.js",
			"/assets/client-bLCk0icn.js",
			"/assets/auth-card-85ccPt56.js",
			"/assets/remember-session-Db6chzQY.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
