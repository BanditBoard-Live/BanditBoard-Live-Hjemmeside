import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as authClient } from "./client-1vAx-gM_.mjs";
import { t as SiteShell } from "./site-shell-CVniC8n5.mjs";
import { a as inputClass, i as SwitchLink, n as Field, r as Submit, t as AuthCard } from "./auth-card-BYp1MSn4.mjs";
import { n as Route$4 } from "./router-ssqsgyiu.mjs";
import { t as rememberSession } from "./remember-session-s-hZk-nZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-DMUwTmBe.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LoginPage() {
	const { next } = Route$4.useSearch();
	const navigate = useNavigate();
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(false);
	async function onSubmit(event) {
		event.preventDefault();
		setError("");
		setPending(true);
		const result = await authClient.signIn.email({
			email: email.trim().toLowerCase(),
			password
		});
		if (result.error) {
			setPending(false);
			setError("Mail eller adgangskode passer ikke.");
			return;
		}
		await rememberSession(result.data?.token);
		if (next.startsWith("/board")) {
			window.location.href = next;
			return;
		}
		await navigate({ to: "/konto" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthCard, {
		title: "Log ind",
		lede: "Brug den mail og adgangskode, du har fået — eller din egen konto.",
		footer: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Ingen konto endnu? ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchLink, {
			to: "/opret",
			children: "Opret bruger"
		})] }),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "grid gap-4",
			onSubmit,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "E-mail",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						type: "email",
						autoComplete: "username",
						required: true,
						value: email,
						onChange: (e) => setEmail(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Adgangskode",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						type: "password",
						autoComplete: "current-password",
						required: true,
						value: password,
						onChange: (e) => setPassword(e.target.value)
					})
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-danger",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Submit, {
					pending,
					children: "Log ind"
				})
			]
		})
	}) });
}
//#endregion
export { LoginPage as component };
