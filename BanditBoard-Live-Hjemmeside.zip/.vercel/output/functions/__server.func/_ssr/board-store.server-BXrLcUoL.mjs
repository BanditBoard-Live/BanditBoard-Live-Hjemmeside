import { s as __exportAll } from "./ssr.mjs";
import { i as hashPassword$1, r as getSql } from "./db-aDnvainO.mjs";
import { randomBytes } from "node:crypto";
//#region node_modules/.nitro/vite/services/ssr/assets/board-store.server-BXrLcUoL.js
var board_store_server_exports = /* @__PURE__ */ __exportAll({
	createVenueAccount: () => createVenueAccount,
	ensureProfile: () => ensureProfile,
	isValidCode: () => isValidCode,
	listVenues: () => listVenues,
	makeAccessCode: () => makeAccessCode,
	readBoardState: () => readBoardState,
	readProfile: () => readProfile,
	readSettings: () => readSettings,
	regenerateAccessCode: () => regenerateAccessCode,
	removeVenue: () => removeVenue,
	saveOwnDetails: () => saveOwnDetails,
	setVenueActive: () => setVenueActive,
	updateVenue: () => updateVenue,
	writeBoardState: () => writeBoardState,
	writeSettings: () => writeSettings
});
function asText(value) {
	if (!value) return "";
	if (value instanceof Date) return value.toISOString();
	return String(value);
}
function mapProfile(row) {
	return {
		userId: row.user_id,
		email: row.email ?? "",
		accountName: row.account_name ?? "",
		role: row.role === "admin" ? "admin" : "klub",
		venueName: row.venue_name,
		contactName: row.contact_name,
		phone: row.phone,
		address: row.address,
		postalCode: row.postal_code,
		city: row.city,
		notes: row.notes,
		accessCode: row.access_code,
		active: Boolean(row.active),
		createdAt: asText(row.created_at)
	};
}
var PROFILE_SELECT = `
  select p.user_id, u.email, u.name as account_name, p.role, p.venue_name, p.contact_name,
         p.phone, p.address, p.postal_code, p.city, p.notes, p.access_code, p.active, p.created_at::text as created_at
  from profiles p
  join "user" u on u.id = p.user_id
`;
async function readProfile(userId) {
	const rows = await (await getSql()).query(`${PROFILE_SELECT} where p.user_id = $1`, [userId]);
	return rows[0] ? mapProfile(rows[0]) : null;
}
async function ensureProfile(userId) {
	const existing = await readProfile(userId);
	if (existing) return existing;
	const sql = await getSql();
	const user = (await sql.query(`select email, name from "user" where id = $1`, [userId]))[0];
	if (!user) throw new Error("Brugeren blev ikke fundet.");
	const admins = await sql`select count(*) as n from profiles where role = 'admin'`;
	await sql`
    insert into profiles (user_id, role, venue_name, contact_name)
    values (${userId}, ${Number(admins[0]?.n ?? 0) === 0 ? "admin" : "klub"}, ${user.name || "Min klub"}, ${user.name || ""})
  `;
	const created = await readProfile(userId);
	if (!created) throw new Error("Profilen kunne ikke oprettes.");
	return created;
}
async function saveOwnDetails(userId, input) {
	await ensureProfile(userId);
	const sql = await getSql();
	await sql`
    update profiles set
      venue_name = ${input.venueName},
      contact_name = ${input.contactName},
      phone = ${input.phone},
      address = ${input.address},
      postal_code = ${input.postalCode},
      city = ${input.city}
    where user_id = ${userId}
  `;
	if (input.venueName) await sql`update "user" set name = ${input.venueName}, "updatedAt" = now() where id = ${userId}`;
	const profile = await readProfile(userId);
	if (!profile) throw new Error("Profilen kunne ikke gemmes.");
	return profile;
}
async function requireAdmin(userId) {
	const profile = await ensureProfile(userId);
	if (profile.role !== "admin") throw new Error("Kun administratoren kan gøre det.");
	return profile;
}
function makeAccessCode(venueName) {
	return `${(venueName.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-zA-Z]/g, "").toUpperCase().slice(0, 4) || "BAND").padEnd(4, "X")}-${String(Math.floor(1e3 + Math.random() * 9e3))}`;
}
function isValidCode(code) {
	return /^[A-Za-z0-9-]{8,40}$/.test(code);
}
async function createVenueAccount(adminId, input) {
	await requireAdmin(adminId);
	const code = input.accessCode || makeAccessCode(input.venueName);
	if (!isValidCode(code)) throw new Error("Adgangskoden skal være 8–40 tegn: bogstaver, tal og bindestreg.");
	const sql = await getSql();
	if ((await sql.query(`select id from "user" where lower(email) = lower($1)`, [input.email]))[0]) throw new Error("Der findes allerede en bruger med den e-mail.");
	const userId = randomBytes(24).toString("base64url");
	const hash = await hashPassword$1(code);
	await sql`
    insert into "user" (id, name, email, "emailVerified", "createdAt", "updatedAt")
    values (${userId}, ${input.venueName}, ${input.email}, true, now(), now())
  `;
	await sql`
    insert into account (id, "accountId", "providerId", "userId", password, "createdAt", "updatedAt")
    values (${randomBytes(24).toString("base64url")}, ${userId}, 'credential', ${userId}, ${hash}, now(), now())
  `;
	await sql`
    insert into profiles (
      user_id, role, venue_name, contact_name, phone, address, postal_code, city, notes, access_code, created_by
    ) values (
      ${userId}, 'klub', ${input.venueName}, ${input.contactName}, ${input.phone},
      ${input.address}, ${input.postalCode}, ${input.city}, ${input.notes}, ${code}, ${adminId}
    )
  `;
	const profile = await readProfile(userId);
	if (!profile) throw new Error("Profilen kunne ikke gemmes.");
	return {
		profile,
		accessCode: code
	};
}
async function listVenues(adminId) {
	await requireAdmin(adminId);
	return (await (await getSql()).query(`${PROFILE_SELECT} order by p.created_at desc`)).map(mapProfile);
}
async function updateVenue(adminId, input) {
	await requireAdmin(adminId);
	const sql = await getSql();
	await sql`
    update profiles set
      venue_name = ${input.venueName},
      contact_name = ${input.contactName},
      phone = ${input.phone},
      address = ${input.address},
      postal_code = ${input.postalCode},
      city = ${input.city},
      notes = ${input.notes}
    where user_id = ${input.userId}
  `;
	if (input.venueName) await sql`update "user" set name = ${input.venueName}, "updatedAt" = now() where id = ${input.userId}`;
	const profile = await readProfile(input.userId);
	if (!profile) throw new Error("Brugeren blev ikke fundet.");
	return profile;
}
async function setVenueActive(adminId, userId, active) {
	if (userId === (await requireAdmin(adminId)).userId && !active) throw new Error("Du kan ikke lukke din egen adgang.");
	await (await getSql())`update profiles set active = ${active} where user_id = ${userId}`;
	const profile = await readProfile(userId);
	if (!profile) throw new Error("Brugeren blev ikke fundet.");
	return profile;
}
async function regenerateAccessCode(adminId, userId, custom) {
	await requireAdmin(adminId);
	const current = await readProfile(userId);
	if (!current) throw new Error("Brugeren blev ikke fundet.");
	const code = (custom || "").trim() || makeAccessCode(current.venueName || current.accountName);
	if (!isValidCode(code)) throw new Error("Adgangskoden skal være 8–40 tegn: bogstaver, tal og bindestreg.");
	const hash = await hashPassword$1(code);
	const sql = await getSql();
	const accounts = await sql.query(`select id from account where "userId" = $1 and "providerId" = 'credential'`, [userId]);
	if (!accounts[0]) throw new Error("Brugeren har ikke en adgangskode. Opret en ny bruger med e-mail.");
	await sql`update account set password = ${hash}, "updatedAt" = now() where id = ${accounts[0].id}`;
	await sql`update profiles set access_code = ${code} where user_id = ${userId}`;
	const profile = await readProfile(userId);
	if (!profile) throw new Error("Koden kunne ikke gemmes.");
	return profile;
}
async function removeVenue(adminId, userId) {
	if (userId === (await requireAdmin(adminId)).userId) throw new Error("Du kan ikke slette din egen konto her.");
	await (await getSql())`delete from "user" where id = ${userId}`;
	return { ok: true };
}
async function readSettings() {
	const row = (await (await getSql())`select facebook, instagram, youtube, contact_email, contact_phone from site_settings where id = 1`)[0];
	return {
		facebook: row?.facebook ?? "",
		instagram: row?.instagram ?? "",
		youtube: row?.youtube ?? "",
		contactEmail: row?.contact_email ?? "",
		contactPhone: row?.contact_phone ?? ""
	};
}
async function writeSettings(adminId, input) {
	await requireAdmin(adminId);
	await (await getSql())`
    insert into site_settings (id, facebook, instagram, youtube, contact_email, contact_phone)
    values (1, ${input.facebook}, ${input.instagram}, ${input.youtube}, ${input.contactEmail}, ${input.contactPhone})
    on conflict (id) do update set
      facebook = excluded.facebook,
      instagram = excluded.instagram,
      youtube = excluded.youtube,
      contact_email = excluded.contact_email,
      contact_phone = excluded.contact_phone
  `;
	return readSettings();
}
async function readBoardState(userId) {
	if (!(await ensureProfile(userId)).active) return {
		state: null,
		updatedAt: null
	};
	const rows = await (await getSql()).query(`select state, updated_at::text as updated_at from board_state where user_id = $1`, [userId]);
	if (!rows[0]) return {
		state: null,
		updatedAt: null
	};
	return {
		state: rows[0].state,
		updatedAt: rows[0].updated_at
	};
}
async function writeBoardState(userId, state) {
	if (!(await ensureProfile(userId)).active) throw new Error("Adgangen er lukket.");
	if (state.length > 2e6) throw new Error("Scoreboardet er for stort til at gemme.");
	return { updatedAt: (await (await getSql())`
    insert into board_state (user_id, state, updated_at)
    values (${userId}, ${state}, now())
    on conflict (user_id) do update set state = excluded.state, updated_at = now()
    returning updated_at::text as updated_at
  `)[0]?.updated_at ?? (/* @__PURE__ */ new Date()).toISOString() };
}
//#endregion
export { writeBoardState as i, ensureProfile as n, readBoardState as r, board_store_server_exports as t };
