import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as getSiteSettings, d as updateVenueAccount, f as useCurrentUserState, i as getMe, l as saveSiteSettings, n as createVenueAccount, o as listVenueAccounts, r as deleteVenueAccount, s as newAccessCode, t as SiteShell, u as setVenueActive } from "./site-shell-CVniC8n5.mjs";
import { a as inputClass, n as Field } from "./auth-card-BYp1MSn4.mjs";
import { t as RedirectToSignIn } from "./gates-CUxTjxua.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-vBV-vcgz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var blank = {
	venueName: "",
	contactName: "",
	email: "",
	phone: "",
	address: "",
	postalCode: "",
	city: "",
	notes: "",
	accessCode: ""
};
function AdminPage() {
	const { user, isPending } = useCurrentUserState();
	const [me, setMe] = (0, import_react.useState)(null);
	const [venues, setVenues] = (0, import_react.useState)([]);
	const [draft, setDraft] = (0, import_react.useState)(blank);
	const [created, setCreated] = (0, import_react.useState)(null);
	const [settings, setSettings] = (0, import_react.useState)({
		facebook: "",
		instagram: "",
		youtube: "",
		contactEmail: "",
		contactPhone: ""
	});
	const [error, setError] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(false);
	const [openId, setOpenId] = (0, import_react.useState)(null);
	async function reload() {
		const [profile, list, site] = await Promise.all([
			getMe(),
			listVenueAccounts(),
			getSiteSettings()
		]);
		setMe(profile);
		setVenues(list);
		setSettings(site);
	}
	(0, import_react.useEffect)(() => {
		if (!user) return;
		reload().catch((err) => setError(err.message || "Admin kunne ikke åbnes."));
	}, [user]);
	if (isPending || user && !me && !error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-6xl px-4 py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-12 w-72 animate-pulse rounded-xl bg-surface-2" })
	}) });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	if (me && me.role !== "admin") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl px-4 py-16 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-5xl",
				children: "Kun administrator"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: "Den her side er til den, der låner scoreboardet ud. Den første bruger på siden er administrator."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/konto",
				className: "mt-6 inline-flex min-h-11 items-center text-primary",
				children: "Tilbage til kontoen"
			})
		]
	}) });
	function patch(key, value) {
		setDraft((current) => ({
			...current,
			[key]: value
		}));
	}
	async function onCreate(event) {
		event.preventDefault();
		setError("");
		setNote("");
		setPending(true);
		try {
			const result = await createVenueAccount({ data: draft });
			setCreated({
				name: result.profile.venueName,
				email: result.profile.email,
				code: result.accessCode
			});
			setDraft(blank);
			await reload();
		} catch (err) {
			setError(err instanceof Error ? err.message : "Brugeren kunne ikke oprettes.");
		} finally {
			setPending(false);
		}
	}
	async function copy(code) {
		try {
			await navigator.clipboard.writeText(code);
			setNote("Koden er kopieret.");
		} catch {
			setNote("Markér koden og kopiér den selv.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-6xl gap-8 px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg tracking-widest text-accent",
					children: "ADMIN"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-5xl sm:text-6xl",
					children: "Pubber og klubber"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-muted",
					children: "Opret for eksempel Sanderum Pubben med mail, kontaktperson, telefon og adresse. De får en adgangskode og logger ind på deres egen tavle."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: onCreate,
				className: "grid gap-4 rounded-card border border-line bg-surface p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl",
						children: "Ny bruger"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Pub, klub eller sted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: inputClass,
									required: true,
									value: draft.venueName,
									onChange: (e) => patch("venueName", e.target.value),
									placeholder: "Sanderum Pubben"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Kontaktperson",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: inputClass,
									value: draft.contactName,
									onChange: (e) => patch("contactName", e.target.value)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "E-mail",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: inputClass,
									type: "email",
									required: true,
									value: draft.email,
									onChange: (e) => patch("email", e.target.value),
									placeholder: "kontakt@sanderumpubben.dk"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Telefon",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: inputClass,
									value: draft.phone,
									onChange: (e) => patch("phone", e.target.value)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Adresse",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: inputClass,
									value: draft.address,
									onChange: (e) => patch("address", e.target.value)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-[7rem_1fr] gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Postnr.",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: inputClass,
										value: draft.postalCode,
										onChange: (e) => patch("postalCode", e.target.value)
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "By",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: inputClass,
										value: draft.city,
										onChange: (e) => patch("city", e.target.value)
									})
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Note",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							value: draft.notes,
							onChange: (e) => patch("notes", e.target.value),
							placeholder: "Udlånt til klubaften, hentes fredag…"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Adgangskode — lad feltet stå tomt, så laves den selv",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							value: draft.accessCode,
							onChange: (e) => patch("accessCode", e.target.value),
							placeholder: "SAND-4821",
							autoComplete: "off"
						})
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-danger",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						disabled: pending,
						className: "min-h-12 rounded-xl bg-primary font-display text-2xl text-primary-fg disabled:opacity-60",
						children: pending ? "Opretter…" : "Opret bruger og kode"
					})
				]
			}),
			created ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card border border-primary bg-deep p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [created.name, " kan logge ind med"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm",
						children: created.email
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-6xl text-primary",
						children: created.code
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-11 rounded-xl bg-surface-2 px-4",
							onClick: () => void copy(created.code),
							children: "Kopiér kode"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-11 rounded-xl px-4 text-muted",
							onClick: () => setCreated(null),
							children: "Skjul"
						})]
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl",
						children: "Brugere"
					}),
					note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-ok",
						children: note
					}) : null,
					venues.map((venue) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-card border border-line bg-surface p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-3xl",
										children: venue.venueName || venue.accountName
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm text-muted",
										children: [
											venue.email,
											venue.contactName ? ` · ${venue.contactName}` : "",
											venue.phone ? ` · ${venue.phone}` : ""
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted",
										children: [
											venue.address,
											venue.postalCode,
											venue.city
										].filter(Boolean).join(", ") || "Ingen adresse endnu"
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-right",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs tracking-wide text-muted",
										children: venue.role === "admin" ? "ADMIN" : venue.active ? "ÅBEN" : "LUKKET"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-3xl text-primary",
										children: venue.accessCode || "—"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap gap-2",
								children: [
									venue.accessCode ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "min-h-11 rounded-xl border border-line px-3 text-sm",
										onClick: () => void copy(venue.accessCode),
										children: "Kopiér kode"
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "min-h-11 rounded-xl border border-line px-3 text-sm",
										onClick: () => setOpenId(openId === venue.userId ? null : venue.userId),
										children: openId === venue.userId ? "Luk" : "Ret"
									}),
									venue.role !== "admin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "min-h-11 rounded-xl border border-line px-3 text-sm",
											onClick: () => {
												newAccessCode({ data: { userId: venue.userId } }).then(async (next) => {
													setNote(`Ny kode til ${next.venueName}: ${next.accessCode}`);
													setCreated({
														name: next.venueName,
														email: next.email,
														code: next.accessCode
													});
													await reload();
												}).catch((err) => setError(err.message));
											},
											children: "Ny kode"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "min-h-11 rounded-xl border border-line px-3 text-sm",
											onClick: () => {
												setVenueActive({ data: {
													userId: venue.userId,
													active: !venue.active
												} }).then(() => reload()).catch((err) => setError(err.message));
											},
											children: venue.active ? "Luk adgang" : "Åbn adgang"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "min-h-11 rounded-xl px-3 text-sm text-danger",
											onClick: () => {
												if (!window.confirm(`Slet ${venue.venueName || venue.email}? Deres tavle slettes også.`)) return;
												deleteVenueAccount({ data: { userId: venue.userId } }).then(() => reload()).catch((err) => setError(err.message));
											},
											children: "Slet"
										})
									] }) : null
								]
							}),
							openId === venue.userId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VenueEditor, {
								venue,
								onSaved: () => void reload().then(() => setNote("Oplysningerne er gemt."))
							}) : null
						]
					}, venue.userId))
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "grid gap-4 rounded-card border border-line bg-surface p-5",
				onSubmit: (event) => {
					event.preventDefault();
					setError("");
					saveSiteSettings({ data: settings }).then((next) => {
						setSettings(next);
						setNote("Bunden af siden er opdateret.");
					}).catch((err) => setError(err.message));
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl",
						children: "Bund og sociale medier"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Links skal starte med https://. Ikonerne vises altid nederst — de bliver klikbare, når der står et link."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Facebook",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							value: settings.facebook,
							onChange: (e) => setSettings({
								...settings,
								facebook: e.target.value
							}),
							placeholder: "https://facebook.com/…"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Instagram",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							value: settings.instagram,
							onChange: (e) => setSettings({
								...settings,
								instagram: e.target.value
							}),
							placeholder: "https://instagram.com/…"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "YouTube",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							value: settings.youtube,
							onChange: (e) => setSettings({
								...settings,
								youtube: e.target.value
							}),
							placeholder: "https://youtube.com/…"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Telefon i bunden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: inputClass,
								value: settings.contactPhone,
								onChange: (e) => setSettings({
									...settings,
									contactPhone: e.target.value
								})
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Mail i bunden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: inputClass,
								value: settings.contactEmail,
								onChange: (e) => setSettings({
									...settings,
									contactEmail: e.target.value
								})
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "min-h-12 rounded-xl bg-surface-2 font-display text-2xl",
						children: "Gem bunden"
					})
				]
			})
		]
	}) });
}
function VenueEditor({ venue, onSaved }) {
	const [form, setForm] = (0, import_react.useState)(venue);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [localError, setLocalError] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "mt-4 grid gap-3 border-t border-line pt-4",
		onSubmit: (event) => {
			event.preventDefault();
			setBusy(true);
			setLocalError("");
			updateVenueAccount({ data: {
				userId: venue.userId,
				venueName: form.venueName,
				contactName: form.contactName,
				email: form.email,
				phone: form.phone,
				address: form.address,
				postalCode: form.postalCode,
				city: form.city,
				notes: form.notes,
				accessCode: ""
			} }).then(() => onSaved()).catch((err) => setLocalError(err.message)).finally(() => setBusy(false));
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Navn",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							value: form.venueName,
							onChange: (e) => setForm({
								...form,
								venueName: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Kontaktperson",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							value: form.contactName,
							onChange: (e) => setForm({
								...form,
								contactName: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Telefon",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							value: form.phone,
							onChange: (e) => setForm({
								...form,
								phone: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Adresse",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							value: form.address,
							onChange: (e) => setForm({
								...form,
								address: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Postnr.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							value: form.postalCode,
							onChange: (e) => setForm({
								...form,
								postalCode: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "By",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							value: form.city,
							onChange: (e) => setForm({
								...form,
								city: e.target.value
							})
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Note",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: form.notes,
					onChange: (e) => setForm({
						...form,
						notes: e.target.value
					})
				})
			}),
			localError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: localError
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				disabled: busy,
				className: "min-h-11 rounded-xl bg-primary px-4 font-display text-xl text-primary-fg disabled:opacity-60",
				children: busy ? "Gemmer…" : "Gem ændringer"
			})
		]
	});
}
//#endregion
export { AdminPage as component };
