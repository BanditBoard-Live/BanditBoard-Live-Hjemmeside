import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Shield, d as LayoutGrid, h as Clapperboard, i as Trophy, l as Settings, n as Users, p as History, r as Tv, s as Smartphone, u as MonitorPlay } from "../_libs/lucide-react.mjs";
import { c as saveMyProfile, f as useCurrentUserState, i as getMe, t as SiteShell } from "./site-shell-CVniC8n5.mjs";
import { a as inputClass, n as Field } from "./auth-card-BYp1MSn4.mjs";
import { t as RedirectToSignIn } from "./gates-CUxTjxua.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/konto-CQoh76tV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var tools = [
	{
		href: "/board.html",
		icon: Trophy,
		title: "Scoreboard",
		text: "Spil, point, skæve og aktiv spiller."
	},
	{
		href: "/board.html#players",
		icon: Users,
		title: "Kartotek",
		text: "Spillere, hold og import."
	},
	{
		href: "/board.html#tour",
		icon: LayoutGrid,
		title: "Turneringer",
		text: "Gem, åbn og kør turneringen."
	},
	{
		href: "/board.html#matrix",
		icon: LayoutGrid,
		title: "Oversigt",
		text: "Hold, borde og kampprogram."
	},
	{
		href: "/board.html#tv",
		icon: Tv,
		title: "TV",
		text: "Storskærm til bord 1."
	},
	{
		href: "/board.html#overlay/1",
		icon: MonitorPlay,
		title: "OBS",
		text: "Overlay i 1920×1080."
	},
	{
		href: "/board.html#turnering",
		icon: Clapperboard,
		title: "Turneringsskærm",
		text: "Oversigten til storskærm."
	},
	{
		href: "/board.html#sponsor",
		icon: Clapperboard,
		title: "Sponsorer",
		text: "Sponsorboardet alene."
	},
	{
		href: "/board.html#history",
		icon: History,
		title: "Historik",
		text: "Kampe, point og eksport."
	},
	{
		href: "/board.html#settings",
		icon: Settings,
		title: "Indstillinger",
		text: "Design, timer, borde og remote."
	},
	{
		href: "/board.html#remote",
		icon: Smartphone,
		title: "Remote",
		text: "Koder til telefonen på aftenen."
	},
	{
		href: "/board.html#mig",
		icon: Users,
		title: "Spillernes side",
		text: "QR, så spillerne kan se sig selv."
	}
];
function AccountPage() {
	const { user, isPending } = useCurrentUserState();
	const [profile, setProfile] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	const [saved, setSaved] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!user) return;
		getMe().then(setProfile).catch((err) => setError(err.message || "Kontoen kunne ikke hentes."));
	}, [user]);
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-6xl px-4 py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-12 w-64 animate-pulse rounded-xl bg-surface-2" })
	}) });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	async function onSubmit(event) {
		event.preventDefault();
		if (!profile) return;
		setPending(true);
		setSaved("");
		setError("");
		try {
			const next = await saveMyProfile({ data: {
				venueName: profile.venueName,
				contactName: profile.contactName,
				email: profile.email,
				phone: profile.phone,
				address: profile.address,
				postalCode: profile.postalCode,
				city: profile.city,
				notes: profile.notes,
				accessCode: ""
			} });
			setProfile(next);
			setSaved("Oplysningerne er gemt.");
		} catch (err) {
			setError(err instanceof Error ? err.message : "Kunne ikke gemme.");
		} finally {
			setPending(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-lg tracking-widest text-primary",
				children: "LOGGET IND"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-5xl sm:text-6xl",
				children: profile?.venueName || user.displayName || "Din konto"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted",
				children: profile?.email || user.primaryEmail
			}),
			profile?.active === false ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 rounded-xl border border-danger/40 bg-surface px-4 py-3 text-sm text-danger",
				children: "Adgangen er lukket. Kontakt administratoren."
			}) : null,
			profile?.role === "admin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/admin",
				className: "mt-5 inline-flex min-h-11 items-center gap-2 rounded-xl border border-line bg-surface px-4 font-semibold text-primary",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, {
					className: "size-4",
					"aria-hidden": "true"
				}), "Admin — opret pubber og koder"]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
				children: tools.map(({ href, icon: Icon, title, text }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href,
					className: "rounded-card border border-line bg-surface p-4 transition hover:border-primary",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "mb-2 size-5 text-primary",
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl",
							children: title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: text
						})
					]
				}, href + title))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "mt-10 grid max-w-2xl gap-4 rounded-card border border-line bg-surface p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl",
						children: "Sted og kontakt"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Navn",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							value: profile?.venueName ?? "",
							onChange: (e) => setProfile((p) => p ? {
								...p,
								venueName: e.target.value
							} : p)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Kontaktperson",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							value: profile?.contactName ?? "",
							onChange: (e) => setProfile((p) => p ? {
								...p,
								contactName: e.target.value
							} : p)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Telefon",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							value: profile?.phone ?? "",
							onChange: (e) => setProfile((p) => p ? {
								...p,
								phone: e.target.value
							} : p)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Adresse",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							value: profile?.address ?? "",
							onChange: (e) => setProfile((p) => p ? {
								...p,
								address: e.target.value
							} : p)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-[8rem_1fr]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Postnr.",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: inputClass,
								value: profile?.postalCode ?? "",
								onChange: (e) => setProfile((p) => p ? {
									...p,
									postalCode: e.target.value
								} : p)
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "By",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: inputClass,
								value: profile?.city ?? "",
								onChange: (e) => setProfile((p) => p ? {
									...p,
									city: e.target.value
								} : p)
							})
						})]
					}),
					profile?.accessCode ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: ["Jeres adgangskode: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-2xl text-fg",
							children: profile.accessCode
						})]
					}) : null,
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-danger",
						children: error
					}) : null,
					saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-ok",
						children: saved
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						disabled: pending || !profile,
						className: "min-h-12 rounded-xl bg-primary font-display text-2xl text-primary-fg disabled:opacity-60",
						children: pending ? "Gemmer…" : "Gem oplysninger"
					})
				]
			})
		]
	}) });
}
//#endregion
export { AccountPage as component };
