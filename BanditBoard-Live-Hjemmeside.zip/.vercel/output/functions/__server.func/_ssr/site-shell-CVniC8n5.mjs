import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { i as signOut, t as authClient } from "./client-1vAx-gM_.mjs";
import { i as hasGateSessionMarker } from "./verify.server-n9_wdzwf.mjs";
import { t as authMiddleware } from "./middleware-C5KKCx1B.mjs";
import { f as Instagram, m as Facebook, t as Youtube } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/site-shell-CVniC8n5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Current user + loading state. Same behavior in live preview and when deployed:
*   - Auth enabled -> the real signed-in user; `user` is `null` while
*                            the session resolves (`isPending: true`) and when
*                            signed out (`isPending: false`). Session comes from
*                            Better Auth `useSession()` → `/api/auth/get-session`
*                            (cookie when deployed; bearer in live preview).
*   - Auth disabled (`VITE_AUTH_ENABLED=false`) -> `DEV_USER`, never pending.
*
* Protect a route by waiting out `isPending` before acting on `user` —
* redirecting on `user: null` alone bounces signed-in visitors to sign-in on
* every hard reload:
*
*   import { RedirectToSignIn } from "@/lib/auth/gates";
*   const { user, isPending } = useCurrentUserState();
*   if (isPending) return null;              // still resolving — don't redirect yet
*   if (!user) return <RedirectToSignIn />;  // definitely signed out
*
* `authEnabled` is a module-level constant fixed at load, so the guarded hook
* call keeps a stable hook order across every render of a given component.
*/
function useCurrentUserState() {
	const { data, isPending } = authClient.useSession();
	const user = data?.user;
	return {
		user: user ? {
			id: user.id,
			displayName: user.name ?? null,
			primaryEmail: user.email ?? null,
			profileImageUrl: user.image ?? null,
			isDevFallback: false
		} : null,
		isPending
	};
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function clip(value, max) {
	return String(value ?? "").trim().slice(0, max);
}
function draft(input, withEmail) {
	const email = clip(input?.email, 160).toLowerCase();
	if (withEmail && !EMAIL.test(email)) throw new Error("Skriv en gyldig e-mail.");
	const venueName = clip(input?.venueName, 120);
	if (!venueName) throw new Error("Skriv navnet på pubben eller klubben.");
	return {
		venueName,
		contactName: clip(input?.contactName, 120),
		email,
		phone: clip(input?.phone, 40),
		address: clip(input?.address, 160),
		postalCode: clip(input?.postalCode, 12),
		city: clip(input?.city, 80),
		notes: clip(input?.notes, 500),
		accessCode: clip(input?.accessCode, 40)
	};
}
function safeUrl(value) {
	const url = clip(value, 300);
	if (!url) return "";
	if (!/^https:\/\/[^\s]+$/i.test(url)) throw new Error("Links skal starte med https://");
	return url;
}
var getSiteSettings = createServerFn({ method: "GET" }).handler(createSsrRpc("95af979cd9c6fe0850bc8ca62cd49729b8407cd159ceea4b3a1b92bb3c408b3a"));
var getMe = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("9581aeb256054aa89052672c1dce675bf13e817fa5ea96749784b66f232e27be"));
var saveMyProfile = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => draft(input, false)).handler(createSsrRpc("7374dcb755ea16bbbaae8ecad206c6afc6fa514b99a9803e6b7395ca01a646c3"));
var listVenueAccounts = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("252d170311eca9a7eeaf7266d37e0ca2e305825a98bd5f5988da9fed8ab4749d"));
var createVenueAccount = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => draft(input, true)).handler(createSsrRpc("b3b8491eaa4194d5d5370ac68d0a22ba34416ed938efad9f2258d2a39e40b14d"));
var updateVenueAccount = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const userId = clip(input?.userId, 80);
	if (!userId) throw new Error("Brugeren mangler.");
	return {
		userId,
		...draft(input, false)
	};
}).handler(createSsrRpc("a5a0754cbefdbdf26cd6dcf131546dc34667672095cd183671467270fa1ce323"));
var setVenueActive = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	userId: clip(input?.userId, 80),
	active: Boolean(input?.active)
})).handler(createSsrRpc("a12730fec4a2ededb1ac62773e615890edca68dbbbba4854a541c63ac11c7b94"));
var newAccessCode = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	userId: clip(input?.userId, 80),
	accessCode: clip(input?.accessCode, 40)
})).handler(createSsrRpc("bc39d1adf6957ccd307c1a29a0b67225abce624a614897bd8021ae39f4df90fc"));
var deleteVenueAccount = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const userId = clip(input?.userId, 80);
	if (!userId) throw new Error("Brugeren mangler.");
	return { userId };
}).handler(createSsrRpc("a391a23456c336eea8cac6d63ee26259dbda598c963b6b90e9a17026e127dbd0"));
var saveSiteSettings = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	facebook: safeUrl(input?.facebook),
	instagram: safeUrl(input?.instagram),
	youtube: safeUrl(input?.youtube),
	contactEmail: clip(input?.contactEmail, 160),
	contactPhone: clip(input?.contactPhone, 40)
})).handler(createSsrRpc("60d93bea402f8b33e3d31012d2226f2362fedba883cf3291972a17528a71dc8d"));
var emptySettings = {
	facebook: "",
	instagram: "",
	youtube: "",
	contactEmail: "",
	contactPhone: ""
};
function SiteShell({ children }) {
	const { user, isPending } = useCurrentUserState();
	const [settings, setSettings] = (0, import_react.useState)(emptySettings);
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const gate = typeof document !== "undefined" && hasGateSessionMarker();
	(0, import_react.useEffect)(() => {
		getSiteSettings().then(setSettings).catch(() => setSettings(emptySettings));
	}, []);
	const socials = [
		{
			href: settings.facebook,
			label: "Facebook",
			icon: Facebook
		},
		{
			href: settings.instagram,
			label: "Instagram",
			icon: Instagram
		},
		{
			href: settings.youtube,
			label: "YouTube",
			icon: Youtube
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-screen flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-20 border-b border-line bg-bg/90 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-wrap items-center gap-3 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "mr-auto flex items-center",
						"aria-label": "BanditBoard Live, forside",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/branding/logo.png",
							alt: "BanditBoard Live",
							className: "h-10 w-auto max-w-44 object-contain sm:h-12 sm:max-w-56"
						})
					}), isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-11 w-36 animate-pulse rounded-xl bg-surface-2" }) : user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShellLink, {
								to: "/konto",
								children: "Konto"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "/board.html",
								className: "inline-flex min-h-11 items-center rounded-xl bg-primary px-4 font-display text-lg font-bold text-primary-fg",
								children: "Scoreboard"
							}),
							!gate ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: signingOut,
								onClick: () => {
									setSigningOut(true);
									signOut("/").catch(() => setSigningOut(false));
								},
								className: "inline-flex min-h-11 items-center px-3 text-sm text-muted disabled:opacity-60",
								children: signingOut ? "Logger ud…" : "Log ud"
							}) : null
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "flex flex-wrap items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/login",
							search: { next: "/konto" },
							className: "inline-flex min-h-11 items-center rounded-xl px-3 text-sm font-semibold text-muted hover:text-fg",
							children: "Log ind"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/opret",
							className: "inline-flex min-h-11 items-center rounded-xl bg-primary px-4 font-display text-lg font-bold text-primary-fg",
							children: "Opret bruger"
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "flex-1",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "border-t border-line bg-deep",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:grid-cols-[1.4fr_1fr_1fr]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/branding/logo.png",
							alt: "",
							className: "mb-4 h-12 w-auto object-contain"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "max-w-sm text-sm text-muted",
							children: "Live scoreboard til billard, dart og turneringer. Samme tavle på telefon, TV og storskærm."
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-3 font-display text-xl text-fg",
							children: "Sider"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "space-y-2 text-sm text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/",
									className: "hover:text-fg",
									children: "Forside"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/login",
									search: { next: "/konto" },
									className: "hover:text-fg",
									children: "Log ind"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/opret",
									className: "hover:text-fg",
									children: "Opret bruger"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/konto",
									className: "hover:text-fg",
									children: "Min konto"
								}) })
							]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mb-3 font-display text-xl text-fg",
								children: "Følg med"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-2",
								children: socials.map(({ href, label, icon: Icon }) => href ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href,
									target: "_blank",
									rel: "noreferrer",
									"aria-label": label,
									className: "grid size-11 place-items-center rounded-xl border border-line bg-surface text-primary",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
										className: "size-5",
										"aria-hidden": "true"
									})
								}, label) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									title: `${label} tilføjes under Admin`,
									className: "grid size-11 place-items-center rounded-xl border border-line bg-surface text-muted",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
										className: "size-5",
										"aria-hidden": "true"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "sr-only",
										children: label
									})]
								}, label))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-4 text-sm text-muted",
								children: [
									settings.contactPhone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block",
										children: settings.contactPhone
									}) : null,
									settings.contactEmail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block",
										children: settings.contactEmail
									}) : null,
									!settings.contactPhone && !settings.contactEmail ? "Kontakt og sociale medier sættes i admin-panelet." : null
								]
							})
						] })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border-t border-line px-4 py-4 text-center text-xs text-muted",
					children: "BanditBoard Live"
				})]
			})
		]
	});
}
function ShellLink({ to, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to,
		className: "inline-flex min-h-11 items-center rounded-xl px-3 text-sm font-semibold text-muted hover:text-fg",
		children
	});
}
//#endregion
export { getSiteSettings as a, saveMyProfile as c, updateVenueAccount as d, useCurrentUserState as f, getMe as i, saveSiteSettings as l, createVenueAccount as n, listVenueAccounts as o, deleteVenueAccount as r, newAccessCode as s, SiteShell as t, setVenueActive as u };
