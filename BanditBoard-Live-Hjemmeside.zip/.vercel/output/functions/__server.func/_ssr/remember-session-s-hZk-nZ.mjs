import { t as authClient } from "./client-1vAx-gM_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/remember-session-s-hZk-nZ.js
/** Keep the live-preview bearer so scoreboardet og serverkald kan se sessionen. */
async function rememberSession(token) {
	if (!token || typeof window === "undefined") return;
	try {
		window.sessionStorage.setItem("grok-auth.bearer-token", token);
	} catch {}
	try {
		await authClient.getSession();
	} catch {}
}
//#endregion
export { rememberSession as t };
