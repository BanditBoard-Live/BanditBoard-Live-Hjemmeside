import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-C5KKCx1B.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/venues-BQAGqpFd.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function clip(value, max) {
	return String(value ?? "").trim().slice(0, max);
}
function draft(input, withEmail) {
	const email = clip(input?.email, 160).toLowerCase();
	if (withEmail && !EMAIL.test(email)) throw new Error("Skriv en gyldig e-mail.");
	const venueName = clip(input?.venueName, 120);
	if (!venueName) throw new Error("Skriv navnet på pubben eller klubben.");
	return {
		venueName,
		contactName: clip(input?.contactName, 120),
		email,
		phone: clip(input?.phone, 40),
		address: clip(input?.address, 160),
		postalCode: clip(input?.postalCode, 12),
		city: clip(input?.city, 80),
		notes: clip(input?.notes, 500),
		accessCode: clip(input?.accessCode, 40)
	};
}
function safeUrl(value) {
	const url = clip(value, 300);
	if (!url) return "";
	if (!/^https:\/\/[^\s]+$/i.test(url)) throw new Error("Links skal starte med https://");
	return url;
}
var getSiteSettings_createServerFn_handler = createServerRpc({
	id: "95af979cd9c6fe0850bc8ca62cd49729b8407cd159ceea4b3a1b92bb3c408b3a",
	name: "getSiteSettings",
	filename: "src/lib/venues.ts"
}, (opts) => getSiteSettings.__executeServer(opts));
var getSiteSettings = createServerFn({ method: "GET" }).handler(getSiteSettings_createServerFn_handler, async () => {
	const { readSettings } = await import("./board-store.server-BXrLcUoL.mjs").then((n) => n.t);
	return readSettings();
});
var getMe_createServerFn_handler = createServerRpc({
	id: "9581aeb256054aa89052672c1dce675bf13e817fa5ea96749784b66f232e27be",
	name: "getMe",
	filename: "src/lib/venues.ts"
}, (opts) => getMe.__executeServer(opts));
var getMe = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getMe_createServerFn_handler, async ({ context }) => {
	const { ensureProfile } = await import("./board-store.server-BXrLcUoL.mjs").then((n) => n.t);
	return ensureProfile(context.userId);
});
var saveMyProfile_createServerFn_handler = createServerRpc({
	id: "7374dcb755ea16bbbaae8ecad206c6afc6fa514b99a9803e6b7395ca01a646c3",
	name: "saveMyProfile",
	filename: "src/lib/venues.ts"
}, (opts) => saveMyProfile.__executeServer(opts));
var saveMyProfile = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => draft(input, false)).handler(saveMyProfile_createServerFn_handler, async ({ context, data }) => {
	const { saveOwnDetails } = await import("./board-store.server-BXrLcUoL.mjs").then((n) => n.t);
	return saveOwnDetails(context.userId, data);
});
var listVenueAccounts_createServerFn_handler = createServerRpc({
	id: "252d170311eca9a7eeaf7266d37e0ca2e305825a98bd5f5988da9fed8ab4749d",
	name: "listVenueAccounts",
	filename: "src/lib/venues.ts"
}, (opts) => listVenueAccounts.__executeServer(opts));
var listVenueAccounts = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listVenueAccounts_createServerFn_handler, async ({ context }) => {
	const { listVenues } = await import("./board-store.server-BXrLcUoL.mjs").then((n) => n.t);
	return listVenues(context.userId);
});
var createVenueAccount_createServerFn_handler = createServerRpc({
	id: "b3b8491eaa4194d5d5370ac68d0a22ba34416ed938efad9f2258d2a39e40b14d",
	name: "createVenueAccount",
	filename: "src/lib/venues.ts"
}, (opts) => createVenueAccount.__executeServer(opts));
var createVenueAccount = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => draft(input, true)).handler(createVenueAccount_createServerFn_handler, async ({ context, data }) => {
	const { createVenueAccount: create } = await import("./board-store.server-BXrLcUoL.mjs").then((n) => n.t);
	return create(context.userId, data);
});
var updateVenueAccount_createServerFn_handler = createServerRpc({
	id: "a5a0754cbefdbdf26cd6dcf131546dc34667672095cd183671467270fa1ce323",
	name: "updateVenueAccount",
	filename: "src/lib/venues.ts"
}, (opts) => updateVenueAccount.__executeServer(opts));
var updateVenueAccount = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const userId = clip(input?.userId, 80);
	if (!userId) throw new Error("Brugeren mangler.");
	return {
		userId,
		...draft(input, false)
	};
}).handler(updateVenueAccount_createServerFn_handler, async ({ context, data }) => {
	const { updateVenue } = await import("./board-store.server-BXrLcUoL.mjs").then((n) => n.t);
	return updateVenue(context.userId, data);
});
var setVenueActive_createServerFn_handler = createServerRpc({
	id: "a12730fec4a2ededb1ac62773e615890edca68dbbbba4854a541c63ac11c7b94",
	name: "setVenueActive",
	filename: "src/lib/venues.ts"
}, (opts) => setVenueActive.__executeServer(opts));
var setVenueActive = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	userId: clip(input?.userId, 80),
	active: Boolean(input?.active)
})).handler(setVenueActive_createServerFn_handler, async ({ context, data }) => {
	const { setVenueActive: setActive } = await import("./board-store.server-BXrLcUoL.mjs").then((n) => n.t);
	return setActive(context.userId, data.userId, data.active);
});
var newAccessCode_createServerFn_handler = createServerRpc({
	id: "bc39d1adf6957ccd307c1a29a0b67225abce624a614897bd8021ae39f4df90fc",
	name: "newAccessCode",
	filename: "src/lib/venues.ts"
}, (opts) => newAccessCode.__executeServer(opts));
var newAccessCode = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	userId: clip(input?.userId, 80),
	accessCode: clip(input?.accessCode, 40)
})).handler(newAccessCode_createServerFn_handler, async ({ context, data }) => {
	const { regenerateAccessCode } = await import("./board-store.server-BXrLcUoL.mjs").then((n) => n.t);
	return regenerateAccessCode(context.userId, data.userId, data.accessCode);
});
var deleteVenueAccount_createServerFn_handler = createServerRpc({
	id: "a391a23456c336eea8cac6d63ee26259dbda598c963b6b90e9a17026e127dbd0",
	name: "deleteVenueAccount",
	filename: "src/lib/venues.ts"
}, (opts) => deleteVenueAccount.__executeServer(opts));
var deleteVenueAccount = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const userId = clip(input?.userId, 80);
	if (!userId) throw new Error("Brugeren mangler.");
	return { userId };
}).handler(deleteVenueAccount_createServerFn_handler, async ({ context, data }) => {
	const { removeVenue } = await import("./board-store.server-BXrLcUoL.mjs").then((n) => n.t);
	return removeVenue(context.userId, data.userId);
});
var saveSiteSettings_createServerFn_handler = createServerRpc({
	id: "60d93bea402f8b33e3d31012d2226f2362fedba883cf3291972a17528a71dc8d",
	name: "saveSiteSettings",
	filename: "src/lib/venues.ts"
}, (opts) => saveSiteSettings.__executeServer(opts));
var saveSiteSettings = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	facebook: safeUrl(input?.facebook),
	instagram: safeUrl(input?.instagram),
	youtube: safeUrl(input?.youtube),
	contactEmail: clip(input?.contactEmail, 160),
	contactPhone: clip(input?.contactPhone, 40)
})).handler(saveSiteSettings_createServerFn_handler, async ({ context, data }) => {
	const { writeSettings } = await import("./board-store.server-BXrLcUoL.mjs").then((n) => n.t);
	return writeSettings(context.userId, data);
});
//#endregion
export { createVenueAccount_createServerFn_handler, deleteVenueAccount_createServerFn_handler, getMe_createServerFn_handler, getSiteSettings_createServerFn_handler, listVenueAccounts_createServerFn_handler, newAccessCode_createServerFn_handler, saveMyProfile_createServerFn_handler, saveSiteSettings_createServerFn_handler, setVenueActive_createServerFn_handler, updateVenueAccount_createServerFn_handler };
