import { C as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as signIn } from "./client-1vAx-gM_.mjs";
import { a as GROK_PROVIDERS } from "./verify.server-n9_wdzwf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-card-BYp1MSn4.js
var import_jsx_runtime = require_jsx_runtime();
function AuthCard({ title, lede, children, footer }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid w-full max-w-lg gap-6 px-4 py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/branding/logo.png",
						alt: "",
						className: "mx-auto mb-4 h-16 w-auto object-contain"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-5xl",
						children: title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: lede
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-card border border-line bg-surface p-5",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-center text-sm text-muted",
				children: footer
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-center text-xs tracking-wide text-muted",
					children: "ELLER"
				}), GROK_PROVIDERS.map((provider) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => void signIn(provider.providerId, { callbackURL: "/konto" }),
					className: "min-h-11 rounded-xl border border-line bg-surface-2 px-4 text-sm font-semibold",
					children: ["Fortsæt med ", provider.label]
				}, provider.providerId))]
			})
		]
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "grid gap-1.5 text-sm font-medium",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), children]
	});
}
var inputClass = "min-h-12 w-full rounded-xl border border-line bg-deep px-3 text-base text-fg outline-none focus-visible:border-primary";
function Submit({ children, pending }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "submit",
		disabled: pending,
		className: "mt-2 min-h-12 w-full rounded-xl bg-primary font-display text-2xl text-primary-fg disabled:opacity-60",
		children: pending ? "Vent…" : children
	});
}
function SwitchLink({ to, children }) {
	if (to === "/login") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/login",
		search: { next: "/konto" },
		className: "font-semibold text-primary",
		children
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/opret",
		className: "font-semibold text-primary",
		children
	});
}
//#endregion
export { inputClass as a, SwitchLink as i, Field as n, Submit as r, AuthCard as t };
