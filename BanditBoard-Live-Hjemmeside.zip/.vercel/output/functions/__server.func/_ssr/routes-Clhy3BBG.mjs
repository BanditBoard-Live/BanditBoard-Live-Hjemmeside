import { C as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as LayoutGrid, h as Clapperboard, i as Trophy, n as Users, o as Timer, p as History, s as Smartphone, u as MonitorPlay } from "../_libs/lucide-react.mjs";
import { f as useCurrentUserState, t as SiteShell } from "./site-shell-CVniC8n5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Clhy3BBG.js
var import_jsx_runtime = require_jsx_runtime();
var features = [
	{
		icon: Trophy,
		title: "Billard og dart",
		text: "Skomager, kegle, pointtavle og dart. Skæve, runder, legs og checkout sidder i samme tavle."
	},
	{
		icon: LayoutGrid,
		title: "Flere borde",
		text: "Hvert bord har sin egen kamp. Oversigten viser hold, runder, point og placering."
	},
	{
		icon: MonitorPlay,
		title: "TV og OBS",
		text: "Storskærm, overlay til Streamlabs og et sponsorboard i 1920×1080."
	},
	{
		icon: Timer,
		title: "Timer og sted",
		text: "Fælles nedtælling, dato, klokkeslæt og sted. Det vises på TV og i overlayet."
	},
	{
		icon: Users,
		title: "Kartotek",
		text: "Spillere, hold, kaptajn og import fra Excel eller CSV. Rangliste og historik følger med."
	},
	{
		icon: Smartphone,
		title: "Samme konto overalt",
		text: "Log ind på telefonen og på TV'et. Tavlen gemmes på kontoen og følger med."
	},
	{
		icon: Clapperboard,
		title: "Sponsorer",
		text: "Klublogo, bånd og sponsorer — blandt andet Sanderum Pubben og Ullerslev Pub."
	},
	{
		icon: History,
		title: "Kampene gemmes",
		text: "Historik, pointhistorik og turneringsfiler, så I kan fortsætte hvor I slap."
	}
];
function Home() {
	const { user, isPending } = useCurrentUserState();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative overflow-hidden border-b border-line",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(25,195,255,0.16),transparent_55%)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto grid max-w-6xl items-center gap-10 px-4 py-14 sm:py-20 lg:grid-cols-[1.15fr_0.85fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-4 font-display text-lg tracking-widest text-primary",
						children: "LIVE SCOREBOARD"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "max-w-xl font-display text-5xl text-fg sm:text-7xl",
						children: "Tavlen til pubben, klubben og storskærmen"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 max-w-xl text-base text-muted sm:text-lg",
						children: "BanditBoard Live er scoreboardet til klubaftenen. Opret en bruger, log ind, og kør kampen. Skal tavlen lånes ud — for eksempel til Sanderum Pubben — opretter du dem med mail, kontaktperson og en adgangskode."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 flex min-h-12 flex-wrap gap-3",
						children: isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-12 w-64 animate-pulse rounded-xl bg-surface-2" }) : user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "/board.html",
							className: "inline-flex min-h-12 items-center rounded-xl bg-primary px-5 font-display text-2xl text-primary-fg",
							children: "Åbn scoreboard"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/konto",
							className: "inline-flex min-h-12 items-center rounded-xl border border-line bg-surface px-5 font-display text-2xl",
							children: "Min konto"
						})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/opret",
							className: "inline-flex min-h-12 items-center rounded-xl bg-primary px-5 font-display text-2xl text-primary-fg",
							children: "Opret bruger"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/login",
							search: { next: "/konto" },
							className: "inline-flex min-h-12 items-center rounded-xl border border-line bg-surface px-5 font-display text-2xl",
							children: "Log ind"
						})] })
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-card border border-line bg-surface p-4 shadow-[0_24px_60px_-30px_rgba(25,195,255,0.45)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/branding/logo.png",
							alt: "BanditBoard Live",
							className: "mx-auto mb-4 h-16 w-auto object-contain"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreSample, {
								name: "Sanderum",
								score: "47",
								live: true
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreSample, {
								name: "Ullerslev",
								score: "39"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-center font-display text-lg tracking-wide text-muted",
							children: "BORD 1 · SKOMAGER · RUNDE 4"
						})
					]
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-4 py-14",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl sm:text-5xl",
					children: "Det scoreboardet kan"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-2xl text-muted",
					children: "Samme funktioner som i BanditBoard Live — nu bag login, så hver pub og klub har sin egen tavle."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
					children: features.map(({ icon: Icon, title, text }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-card border border-line bg-surface p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "mb-3 size-6 text-primary",
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-2xl",
								children: title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: text
							})
						]
					}, title))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-y border-line bg-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-6xl items-center gap-8 px-4 py-14 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-lg tracking-widest text-accent",
						children: "UDLÅN"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 font-display text-4xl sm:text-5xl",
						children: "Lån tavlen ud med en kode"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
						className: "mt-6 space-y-4 text-sm text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mr-2 font-display text-2xl text-primary",
								children: "01"
							}), "Den første bruger bliver administrator."] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mr-2 font-display text-2xl text-primary",
								children: "02"
							}), "I admin opretter du pubben: mail, kontaktperson, telefon, adresse og hvad der ellers hører til."] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mr-2 font-display text-2xl text-primary",
								children: "03"
							}), "De får en adgangskode, logger ind og bruger kun deres egen tavle."] })
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
						className: "overflow-hidden rounded-card border border-line bg-deep",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/medier/billard/sponsorer/sanderum-pubben.png",
							alt: "Sanderum Pubben",
							className: "aspect-square w-full object-contain p-4"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
							className: "border-t border-line px-3 py-2 text-center font-display text-xl",
							children: "Sanderum Pubben"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
						className: "overflow-hidden rounded-card border border-line bg-deep",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/medier/billard/sponsorer/ullerslev-pub.png",
							alt: "Ullerslev Pub",
							className: "aspect-square w-full object-contain p-4"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
							className: "border-t border-line px-3 py-2 text-center font-display text-xl",
							children: "Ullerslev Pub"
						})]
					})]
				})]
			})
		})
	] });
}
function ScoreSample({ name, score, live }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `rounded-2xl border px-3 py-4 ${live ? "border-accent bg-deep" : "border-line bg-deep"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between text-xs text-muted",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-semibold",
				children: name
			}), live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-accent",
				children: "LIVE"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "VENTER" })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-center font-display text-6xl text-primary",
			children: score
		})]
	});
}
//#endregion
export { Home as component };
