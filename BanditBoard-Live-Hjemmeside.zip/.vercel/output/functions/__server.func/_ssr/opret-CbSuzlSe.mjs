import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as authClient } from "./client-1vAx-gM_.mjs";
import { c as saveMyProfile, t as SiteShell } from "./site-shell-CVniC8n5.mjs";
import { a as inputClass, i as SwitchLink, n as Field, r as Submit, t as AuthCard } from "./auth-card-BYp1MSn4.mjs";
import { t as rememberSession } from "./remember-session-s-hZk-nZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/opret-CbSuzlSe.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SignupPage() {
	const navigate = useNavigate();
	const [form, setForm] = (0, import_react.useState)({
		venueName: "",
		contactName: "",
		email: "",
		phone: "",
		address: "",
		postalCode: "",
		city: "",
		password: "",
		again: ""
	});
	const [error, setError] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(false);
	function set(key, value) {
		setForm((current) => ({
			...current,
			[key]: value
		}));
	}
	async function onSubmit(event) {
		event.preventDefault();
		setError("");
		if (form.password.length < 8) {
			setError("Adgangskoden skal være mindst 8 tegn.");
			return;
		}
		if (form.password !== form.again) {
			setError("Adgangskoderne er ikke ens.");
			return;
		}
		setPending(true);
		const result = await authClient.signUp.email({
			name: form.venueName.trim() || form.contactName.trim() || "Min klub",
			email: form.email.trim().toLowerCase(),
			password: form.password
		});
		if (result.error) {
			setPending(false);
			setError(result.error.message || "Brugeren kunne ikke oprettes. Prøv en anden e-mail.");
			return;
		}
		await rememberSession(result.data?.token);
		try {
			await saveMyProfile({ data: {
				venueName: form.venueName.trim() || form.contactName.trim() || "Min klub",
				contactName: form.contactName.trim(),
				email: form.email,
				phone: form.phone,
				address: form.address,
				postalCode: form.postalCode,
				city: form.city,
				notes: "",
				accessCode: ""
			} });
		} catch {}
		await navigate({ to: "/konto" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthCard, {
		title: "Opret bruger",
		lede: "Den første bruger bliver administrator og kan oprette pubber med deres egen kode.",
		footer: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Har du allerede en kode? ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchLink, {
			to: "/login",
			children: "Log ind"
		})] }),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "grid gap-4",
			onSubmit,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Klub, pub eller sted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						required: true,
						value: form.venueName,
						onChange: (e) => set("venueName", e.target.value),
						placeholder: "Sanderum Pubben"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Kontaktperson",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						value: form.contactName,
						onChange: (e) => set("contactName", e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "E-mail",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						type: "email",
						autoComplete: "email",
						required: true,
						value: form.email,
						onChange: (e) => set("email", e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Telefon",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						type: "tel",
						autoComplete: "tel",
						value: form.phone,
						onChange: (e) => set("phone", e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Adresse",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						autoComplete: "street-address",
						value: form.address,
						onChange: (e) => set("address", e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-[8rem_1fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Postnr.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							autoComplete: "postal-code",
							value: form.postalCode,
							onChange: (e) => set("postalCode", e.target.value)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "By",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							autoComplete: "address-level2",
							value: form.city,
							onChange: (e) => set("city", e.target.value)
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Adgangskode",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						type: "password",
						autoComplete: "new-password",
						required: true,
						value: form.password,
						onChange: (e) => set("password", e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Gentag adgangskode",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						type: "password",
						autoComplete: "new-password",
						required: true,
						value: form.again,
						onChange: (e) => set("again", e.target.value)
					})
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-danger",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Submit, {
					pending,
					children: "Opret bruger"
				})
			]
		})
	}) });
}
//#endregion
export { SignupPage as component };
